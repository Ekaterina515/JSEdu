// import { renderCards } from "./modules/renderCards.js";
// import { addToCart } from "./modules/addToCart.js";
// renderCards();
// addToCart();
// console.log(2);
// const registrationBtn = document.querySelector(".registration-btn");
// const inputName = document.querySelector("#input-name");
// const inputLastName = document.querySelector("#input-last-name");

// registrationBtn.addEventListener("click", (e) => {
//   e.preventDefault();
//   // console.log(inputName.value);
//   // console.log(inputLastName.value);

//   let user = {};
//   user["name"] = inputName.value;
//   user["last_name"] = inputLastName.value;
//   localStorage.setItem("cart", JSON.stringify(user));
// });

// const cart = JSON.parse(localStorage.getItem("cart"));
// console.log(cart);
